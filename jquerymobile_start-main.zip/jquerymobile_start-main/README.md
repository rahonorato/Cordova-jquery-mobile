# jquerymobile_start
Arquivos base para iniciar o desenvolvimento com o JQuery Mobile
